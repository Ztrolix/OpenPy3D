# OpenPy3D ![Logo](https://raw.githubusercontent.com/Ztrolix/OpenPy3D/main/assets/icon_2.png)
OpenPy3D Is a Python PIP package that you can create 3D objects in Python really easy with.